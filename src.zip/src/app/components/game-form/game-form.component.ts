import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { GameService } from '../../services/game.service';
import { UserService } from '../../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Game, Rating } from '../../models/game.model';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-game-form',
  imports: [FormsModule, CommonModule],
  templateUrl: './game-form.component.html'
})
export class GameFormComponent implements OnInit {
  model: Game = { name:'', description:'', startDate:'', category:'Outro', ratings:[], userIds: [] } as Game;
  editing = false;
  id?: number;
  users: User[] = [];
  categories = ['Ação','RPG','Estratégia','Esporte','Simulação','Outro'];
  rating = 0;

  constructor(private gs: GameService, private us: UserService, private router: Router, private route: ActivatedRoute) {}

  async ngOnInit() {
    this.users = await this.us.getAll();
    this.route.params.subscribe(async params => {
      if (params['id']) {
        this.editing = true;
        this.id = +params['id'];
        const g = await this.gs.getById(this.id);
        if (g) this.model = g as Game;
      }
    });
  }

  async save() {
    if (this.editing && this.id) {
      await this.gs.update(this.id, this.model);
      alert('Jogo atualizado');
    } else {
      await this.gs.add(this.model);
      alert('Jogo cadastrado');
    }
    this.router.navigate(['/games']);
  }

  clear() { 
    this.model = { name:'', description:'', startDate:'', category:'Outro', ratings:[], userIds: [] } as Game;
    this.rating = 0;
  }

  setRating(value: number) {
    this.rating = value;
  const newRating: Rating = { value: this.rating, userId: 1 };
    if (!this.model.ratings) {
      this.model.ratings = [];
    }
    this.model.ratings = [newRating];
  }
}
