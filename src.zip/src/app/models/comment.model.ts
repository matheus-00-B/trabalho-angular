export interface CommentModel {
  id?: number;
  gameId: number;
  userId: number;
  text: string;
  date: string; 
}
